import React from "react";
import { Helmet } from "react-helmet";
import { connect } from "react-redux";
import { Link, Switch, Route } from "react-router-dom";
import "./App.css";

const App = props => {
  return (
    // header section
    <>
      <Helmet>
        <title>Hello from {props.name}</title>
      </Helmet>

      {/* body aspect */}

      <div className="App">
        <h2>WELCOME TO {props.name}</h2>
        <p>
          <Link to="/edit">Edit</Link> to start using{" "}
        </p>
      </div>

    </>
  );
};

// mapStateToProps
const mapStateToProps = state => ({
  name: state.store
});

export default connect(mapStateToProps)(App);
