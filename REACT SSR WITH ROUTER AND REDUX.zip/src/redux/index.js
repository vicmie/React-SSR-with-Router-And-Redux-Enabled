import { combineReducers } from "redux";
import store from "./reducers";

const rootReducer = combineReducers({
  store
});

export default rootReducer;
